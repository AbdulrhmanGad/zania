# -*- coding: utf-8 -*-
from odoo import models, fields, api
from datetime import datetime


class StockReport(models.TransientModel):
    _name = "due.date.report"
    _description = "Check Report"

    due_date = fields.Date(string='Due Date', default=datetime.today(), required=1)
    check_type = fields.Selection([('inbound', 'Received Check'),
                                   ('outbound', 'Issued Check'),
                                   ], string='Type of Check', required=1)
    due_date_exceed = fields.Boolean(string='Duded Checks', default=False)
    daily_report = fields.Boolean(string='Daily Report', default=False)

    @api.multi
    def export_xls(self):
        context = self._context
        datas = {'ids': context.get('active_ids', [])}
        datas['model'] = 'checks.paid'
        datas['form'] = self.read()[0]
        for field in datas['form'].keys():
            if isinstance(datas['form'][field], tuple):
                datas['form'][field] = datas['form'][field][0]
        if context.get('xls_export'):
            return {'type': 'ir.actions.report.xml',
                    'report_name': 'deferred_checks.due_date_check_report_xls.xlsx',
                    'datas': datas,
                    'name': 'Check Report'
                    }
